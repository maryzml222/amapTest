package com.example.maryaidltest;

import android.app.ActivityManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.IBinder;
import android.os.RemoteException;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.example.gaodemapdemo.aidlDemo.IMyAidlInterface;

public class MainActivity extends AppCompatActivity implements ServiceConnection {
    IMyAidlInterface myService;
    Intent intent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initService();

        Button buttonCalc = (Button) findViewById(R.id.buttonCalc);
        TextView result = (TextView) findViewById(R.id.result);


        buttonCalc.setOnClickListener(new View.OnClickListener() {
            EditText value1 = (EditText) findViewById(R.id.value1);
            EditText value2 = (EditText) findViewById(R.id.value2);

            @Override
            public void onClick(View v) {
                int v1, v2;
                v1 = Integer.parseInt(value1.getText().toString());
                v2 = Integer.parseInt(value2.getText().toString());

                try {
                    if (myService != null) {
                        myService.add(v1, v2);
                    }
                } catch (RemoteException e) {
                    e.printStackTrace();
                }
            }
        });
    }

    //连接服务
    private void initService() {
        intent = new Intent();
        intent.setAction("com.example.gaodemapdemo.aidlDemo.IMyAidlInterface");
        intent.setPackage("com.example.gaodemapdemo");
        bindService(intent, this, BIND_AUTO_CREATE);
    }


    @Override
    public void onServiceConnected(ComponentName name, IBinder service) {
        myService = IMyAidlInterface.Stub.asInterface(service);
        Log.e("mary", "-----onServiceConnected ");
    }

    @Override
    public void onServiceDisconnected(ComponentName name) {
        Log.e("mary", "-----onServiceDisconnected ");
        myService = null;

    }

    //断开服务
    private void releaseService() {
        if (isServiceRunning("com.example.gaodemapdemo.aidlDemo.AdditionService")) {
            unbindService(this);
            stopService(intent);
        }
    }

    //防止重复解绑服务报错
    private boolean isServiceRunning(String service_Name) {
        ActivityManager manager =
                (ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
        for (ActivityManager.RunningServiceInfo service : manager.getRunningServices(Integer.MAX_VALUE)) {
            if (service_Name.equals(service.service.getClassName())) {
                return true;
            }
        }
        return false;
    }

}
